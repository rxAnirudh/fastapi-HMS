{
    "success": true,
    "data": {
        "id": 5,
        "marital_status": "",
        "height": "",
        "weight": "",
        "emergency_contact_number": "",
        "city": "",
        "smoking_habits": "",
        "alchol_consumption": "",
        "activity_level": "",
        "occupation": "",
        "first_name": "ddads",
        "last_name": "ddsss",
        "contact_number": "+917020829594",
        "email": "dsssdddss@gmail.com",
        "gender": "male",
        "date_of_birth": "",
        "blood_group": "b+",
        "hospital_id": "",
        "profile_pic": "",
        "authentication_token": {
            "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NjE4NjM1ODMsImVtYWlsIjoiZHNzc2RkZHNzQGdtYWlsLmNvbSIsIm1vYmlsZV9udW1iZXIiOiIrOTE3MDIwODI5NTk0In0.8snb1X1YjIQVtgTH6U2IW5dx7_UvSaUSlwsEc9oSjoA",
            "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NjE4NjM1ODMsImVtYWlsIjoiZHNzc2RkZHNzQGdtYWlsLmNvbSIsIm1vYmlsZV9udW1iZXIiOiIrOTE3MDIwODI5NTk0In0.8snb1X1YjIQVtgTH6U2IW5dx7_UvSaUSlwsEc9oSjoA"
        },
        "allergies": [
            {
                "id": 64,
                "allergy": "allergy 1"
            },
            {
                "id": 65,
                "allergy": "allergy 2"
            }
        ],
        "food_preferences": [
            {
                "id": 1,
                "food_preference": "Food preference 1"
            },
            {
                "id": 2,
                "food_preference": "Food preference 2"
            }
        ],
        "current_medications": [
            {
                "id": 66,
                "current_medication": "current_medication 1"
            }
        ],
        "past_injuries": [
            {
                "past_injury": "Injury 1",
                "id": 9
            },
            {
                "past_injury": "Injury 2",
                "id": 10
            }
        ],
        "past_surgeries": [
            {
                "past_surgery": "Surgery 1",
                "id": 9
            },
            {
                "past_surgery": "Surgery 2",
                "id": 10
            }
        ]
    },
    "message": "New Patient added successfully"
}